-- MySQL dump 10.13  Distrib 5.7.33, for Linux (x86_64)
--
-- Host: db    Database: blog_nodejs
-- ------------------------------------------------------
-- Server version	5.7.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `blog_nodejs`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `blog_nodejs` /*!40100 DEFAULT CHARACTER SET ucs2 COLLATE ucs2_unicode_ci */;

USE `blog_nodejs`;

--
-- Table structure for table `contact`
--

DROP TABLE IF EXISTS `contact`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contact` (
  `ID` int(12) NOT NULL AUTO_INCREMENT,
  `ID_user` int(12) DEFAULT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `content` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reply` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` int(2) DEFAULT NULL,
  `date_contact` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `date_reply` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ID_user` (`ID_user`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contact`
--

LOCK TABLES `contact` WRITE;
/*!40000 ALTER TABLE `contact` DISABLE KEYS */;
INSERT INTO `contact` VALUES (1,1,'vodinhnghia85@gmail.com','Hello','Hi you!',1,'16 02 2021 10:31:21','13 03 2021 10:40:57'),(4,1,'vodinhnghia85@gmail.com','Hỏi thông tin admin.','What are you ask about info?',1,'27 02 2021 10:30:04','13 03 2021 10:41:58'),(5,5,'dinhnghia@gmail.com','Tôi muốn hỏi về vấn đề.','Bạn muốn hỏi về vấn đề gì ?',1,'06 03 2021 10:18:13','13 03 2021 10:42:24'),(6,2,'vothituyetlinh99@gmail.com','test','Ok ',1,'13 03 2021 10:15:47','13 03 2021 10:40:27'),(7,4,'vodinhnghia@gmail.com','Kiểm tra chức năng thông báo phần admin .','',0,'13 03 2021 10:44:25','');
/*!40000 ALTER TABLE `contact` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `getpass`
--

DROP TABLE IF EXISTS `getpass`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `getpass` (
  `ID` int(12) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email_user` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_getpass` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `getpass`
--

LOCK TABLES `getpass` WRITE;
/*!40000 ALTER TABLE `getpass` DISABLE KEYS */;
INSERT INTO `getpass` VALUES (1,'DinhNghia','luongsonbac@gmail.com','14 03 2021 17:09:28'),(2,'Võ Đình Nghĩa','vodinhnghia@gmail.com','14 03 2021 17:11:46'),(3,'Võ Đình Nghĩa','vodinhnghia@gmail.com','14 03 2021 17:13:00'),(4,'Võ Đình Nghĩa','vodinhnghia@gmail.com','14 03 2021 17:15:56'),(5,'Võ Đình Nghĩa','vodinhnghia@gmail.com','14 03 2021 17:18:29'),(6,'VoDinhNghia','admin123@gmail.com','14 03 2021 17:18:42'),(7,'Đình Nghĩa','admin123@gmail.com','14 03 2021 17:19:34'),(8,'Đình Nghĩa','vodinhnghia@gmail.com','14 03 2021 17:19:41'),(9,'Đình Nghĩa','vodinhnghia@gmail.com','14 03 2021 17:19:55'),(10,'Võ Thị Tuyết Linh','vothituyetlinh99@gmail.com','14 03 2021 17:20:15'),(11,'Võ Thị Tuyết Linh','vothituyetlinh99@gmail.com','14 03 2021 17:23:10'),(12,'Võ Đình Nghĩa','vodinhnghia@gmail.com','16 03 2021 07:12:44'),(13,'Võ Đình Nghĩa','vodinhnghiaskype@gmail.com','16 03 2021 07:13:18'),(14,'Võ Đình Nghĩa','vodinhnghiaskype@gmail.com','16 03 2021 07:13:49'),(15,'Võ Đình Nghĩa','vodinhnghiaskype@gmail.com','16 03 2021 07:13:59'),(16,'Võ Đình Nghĩa','vodinhnghiaskype@gmail.com','16 03 2021 20:25:04');
/*!40000 ALTER TABLE `getpass` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `listpost`
--

DROP TABLE IF EXISTS `listpost`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `listpost` (
  `ID` int(12) NOT NULL AUTO_INCREMENT,
  `ID_user` int(12) DEFAULT NULL,
  `title` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `content` text COLLATE utf8_unicode_ci,
  `image` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `privacy` int(2) DEFAULT NULL,
  `date_post` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ID_user` (`ID_user`),
  CONSTRAINT `listpost_ibfk_1` FOREIGN KEY (`ID_user`) REFERENCES `user` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `listpost`
--

LOCK TABLES `listpost` WRITE;
/*!40000 ALTER TABLE `listpost` DISABLE KEYS */;
INSERT INTO `listpost` VALUES (17,2,'Cảm nhận về tết','Nếu dưới mái nhà của mình mà con người ta chẳng cảm nhận được những ấm yên, mái nhà ấy hẳn còn thiếu sự bao dung và thấu hiểu. Nếu có như thế, cũng đừng ngồi yên trong bóng tối, bởi thay đổi bắt đầu từ chính chúng ta. Nếu không thể nhìn thấy ánh sáng trong ngôi nhà của mình, hãy là người chủ động lau cho những vệt tối dần sáng lên...\r\n(Trích dẫn, hình ảnh minh họa ).','/images/uploads/04-02-2021-14980611_834218783384968_1001746565774831532_n.jpg',0,'04 02 2021 20:46:38'),(18,2,'Du xuân Phú Yên','Chắc hẳn Thái Trinh cũng đã tìm hiểu sơ qua về Gành Đá Dĩa, biểu tượng du lịch của Phú Yên. Mùa nào trong năm nơi đây cũng đón tiếp rất nhiều lượt khách tham quan, tuy nhiên mùa xuân và dịp Tết Gành Đá Dĩa là đẹp nhất. Những con sóng vỗ bờ êm đềm xô vào gành đá đen tuyền, tựa như tổ ong khổng lồ bằng đá nằm cạnh đại dương xanh thẳm. Mùa xuân cũng là mùa của rêu xanh, cây cỏ, hoa lá đâm chòi nảy lộc. Nếu bạn và gia đình dạo bước du xuân đến đây sẽ có rất nhiều khung ảnh đẹp và hùng vĩ đang chờ đón.','/images/uploads/04-02-2021-duxuanphuyen.jpg',0,'04 02 2021 21:14:50'),(19,1,'Làng hoa nhộn nhịp đón Tết','Trở về những làng hoa những ngày này, không khí tất bật và rộn ràng. Các vườn hoa nhộn nhịp khách đến tham quan, mua hoa. Người trồng hoa nở nụ cười mãn nguyện sau một thời gian chăm bẵm khó khăn. Tết đến với các làng hoa sớm hơn ở các địa phương khác. \r\n(Trich: Baoquangngai.vn)','/images/uploads/05-02-2021-xuanquangngai.jpg',0,'05 02 2021 12:00:24'),(20,1,'Cảm xúc ngày cuối năm','Bóng chiều dần tắt, tiếng thời gian dường như đang nghiêng về một phía. Nỗi nhớ nhân đôi lên. Chiều đã bắt đầu lạnh, ngân ngấn gió về khiến tia nắng gẫy đôi. Những ngày cuối năm càng trôi nhanh hơn,lòng người hoang hoải…chùng hẳn lại.\r\n(source: https://tanvan.xyz/cam-xuc-ngay-cuoi-nam/)','/images/uploads/06-02-2021-cuoi-nam.jpg',0,'06 02 2021 09:10:33'),(22,1,'Code ngày cuối năm.','Tranh thu code12','/images/uploads/14-02-2021-Screenshot from 2021-02-02 21-23-14.png',1,'14 02 2021 20:35:05'),(24,4,'Chuyện vui lập trình','Ông bà ta thường có câu “Một nụ cười bằng mười thang thuốc bổ” vậy nên sau những giờ làm việc, học tập căng thẳng ta cũng nên tìm một thứ gì đó để giải trí một chút cho vui, giúp công việc đạt kết quả cao hơn. (trichs: https://quantrimang.com/tong-hop-nhung-truyen-cuoi-ba-dao-viet-ve-dan-it-164143)','/images/uploads/03-03-2021-Screenshot from 2021-02-16 19-02-39.png',0,'16 02 2021 10:42:07'),(26,1,'Những ngày cuối tháng 2','Thế rồi tháng 2 lần nữa lại ghé qua đây và chở về một mùa xuân yêu kiều nồng đượm. Tháng hai là độ mùa xuân vừa chín, cây lá đâm chồi, cỏ hoa rợp nở. Nhưng như khúc tản văn mà tôi đã viết, có ai đứng giữa “mùa yêu” ấy mà chợt nhớ tới những thứ khốc khô và buồn bã không nhỉ? Có ai bước giữa mùa tháng hai mà chợt nhớ tới một chút cô đơn, một chút lạnh lùng, một nỗi sầu diệu vợi? Nếu có, thì bài viết hôm nay là dành cho bạn. Xin gửi tới mọi người chùm thơ tháng 2 tâm trạng, lãng mạn, cô đơn và buồn bã nhất mà tôi đã sưu tầm. Hy vọng rằng các bạn cũng sẽ thích những áng thơ tình tháng hai đầy cảm xúc này. Chúc các bạn có những phút giây thật tuyệt bên những vần thơ tình buồn tháng 2 hay!\r\n(Nguồn : https://ocuaso.com/tho-buon/tho-suu-tam/chum-tho-tinh-thang-2-hay.html)','/images/uploads/27-02-2021-thang2.jpg',0,'27 02 2021 10:24:31'),(27,2,'Tháng 2 ngày nhớ ai','Tháng 2 xuân về người có nhớ ...','',0,'27 02 2021 10:28:51'),(28,4,'Tháng 3 sắp tới rồi ','Hello tháng 3 ...','/images/uploads/27-02-2021-sach_cafe.jpg',0,'27 02 2021 10:31:30'),(29,5,'Code dạo tối thứ tư','Mỗi dòng code là một niềm vui.','/images/uploads/06-03-2021-Screenshot from 2021-02-14 11-03-47.png',0,'29 08 2021 20:44:02'),(32,5,'Thứ 7 máu chảy về tim','','/images/uploads/06-03-2021-stt-thu-7-mau-chay-ve-tim-p.jpg',0,'13 03 2021 21:53:33'),(34,7,'Những vần thơ hay.','Bút hoa đưa đẩy hồn thêm lối.\r\nMiệng đọc mắt nhìn đầu lắc lư.','/images/uploads/14-03-2021-Screenshot from 2021-03-14 11-14-39.png',1,'14 03 2021 17:29:31'),(35,8,'Hàng Long Thập Bát Chưởng','Hàng Long Thập Bát Chưởng là bộ chưởng pháp chí cương được lưu truyền giữa các đời bang chủ Cái Bang. Tên gọi của 18 chiêu thức đều lấy từ Kinh Dịch.\r\nTương truyền bộ chưởng pháp này do bang chủ đời thứ nhất của Cái Bang tên Hồng Tứ Hải sáng tạo ra với tên Dịch Kinh Hàng Long Chưởng gồm rất nhiều chiêu. Hậu thế sau này rút gọn còn 18 chưởng....','',1,'14 03 2021 20:55:34'),(36,10,'Biểu cảm về con vật nuôi','Tuổi thơ của ai cũng gắn bó với một loài vật nuôi đáng yêu, đó có thể là chú rùa, chú chim hay chú mèo… Riêng với tôi, tuổi thơ của tôi gắn với chú chó Phi Phi dũng cảm.','/images/uploads/15-03-2021-bieu-cam-ve-con-vat-nuoi-con-cho.jpg',0,'15 03 2021 08:33:09');
/*!40000 ALTER TABLE `listpost` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `manager_avatar`
--

DROP TABLE IF EXISTS `manager_avatar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `manager_avatar` (
  `ID` int(12) NOT NULL AUTO_INCREMENT,
  `ID_user` int(12) DEFAULT NULL,
  `image_update` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_update` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ID_user` (`ID_user`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `manager_avatar`
--

LOCK TABLES `manager_avatar` WRITE;
/*!40000 ALTER TABLE `manager_avatar` DISABLE KEYS */;
INSERT INTO `manager_avatar` VALUES (10,2,'/images/avatars/15-02-2021-photocat.jpg','15 02 2021 19:19:55'),(11,2,'/images/avatars/15-02-2021-106712292_979102752520719_7452376421506811259_n.jpg','15 02 2021 19:24:03'),(12,4,'/images/avatars/16-02-2021-15036301_834215213385325_8760571512419874799_n.jpg','16 02 2021 10:40:42'),(13,4,'/images/avatars/16-02-2021-18870731_709897545885580_1363768799_n.jpg','16 02 2021 10:47:06'),(15,5,'/images/avatars/03-03-2021-2021-01-20-134634.jpg','03 03 2021 20:42:59'),(16,5,'/images/avatars/06-03-2021-photocat.jpg','06 03 2021 10:05:03'),(27,10,'/images/avatars/16-03-2021-avatar-female.jpg','16 03 2021 08:01:35');
/*!40000 ALTER TABLE `manager_avatar` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `share_like_comment`
--

DROP TABLE IF EXISTS `share_like_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `share_like_comment` (
  `ID` int(12) NOT NULL AUTO_INCREMENT,
  `ID_post` int(12) DEFAULT NULL,
  `ID_user` int(12) DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `type` int(12) DEFAULT NULL,
  `status_like` int(12) NOT NULL,
  `status_notify` int(10) DEFAULT NULL,
  `date_implement` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ID_post` (`ID_post`),
  CONSTRAINT `share_like_comment_ibfk_1` FOREIGN KEY (`ID_post`) REFERENCES `listpost` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `share_like_comment`
--

LOCK TABLES `share_like_comment` WRITE;
/*!40000 ALTER TABLE `share_like_comment` DISABLE KEYS */;
INSERT INTO `share_like_comment` VALUES (4,20,1,'like',0,0,0,'14 02 2021 12:05:40'),(5,20,1,'Thật buồn\r\n',1,0,0,'14 02 2021 12:20:31'),(6,20,1,'Chia sẻ cùng nhau',1,0,0,'14 02 2021 12:21:11'),(8,22,1,'like',0,0,0,'15 02 2021 09:12:31'),(9,22,2,'like',0,0,1,'15 02 2021 19:12:06'),(10,22,4,'like',0,0,1,'16 02 2021 10:36:40'),(11,24,4,'like',0,0,0,'16 02 2021 10:42:15'),(12,24,1,'like',0,0,0,'16 02 2021 11:16:45'),(13,24,1,'Hello',1,0,0,'16 02 2021 11:16:56'),(14,18,1,'like',0,0,0,'16 02 2021 11:25:08'),(15,18,1,'Đẹp lắm em.',1,0,0,'16 02 2021 11:25:23'),(16,22,1,'hello',1,0,0,'22 02 2021 13:59:19'),(17,19,1,'like',0,0,0,'22 02 2021 14:02:03'),(18,26,1,'like',0,0,0,'27 02 2021 10:24:38'),(19,26,1,'Tháng 2 ngày cuối ta nhớ ai ...',1,0,0,'27 02 2021 10:25:22'),(20,26,2,'like',0,0,1,'27 02 2021 10:25:37'),(21,26,2,'Anh nhớ ai vậy ?',1,0,1,'27 02 2021 10:25:50'),(22,27,2,'like',0,0,0,'27 02 2021 10:28:54'),(24,27,1,'like',0,0,1,'27 02 2021 10:29:35'),(25,28,4,'like',0,0,0,'27 02 2021 10:31:36'),(26,28,1,'like',0,0,0,'27 02 2021 10:32:22'),(27,28,1,'Ảnh đẹp quá...',1,0,0,'27 02 2021 10:32:35'),(28,17,1,'like',0,0,0,'27 02 2021 11:07:39'),(32,29,1,'like',0,0,0,'06 03 2021 10:00:32'),(33,29,1,'Good like',1,0,0,'06 03 2021 10:00:42'),(34,29,5,'Ok man',1,0,0,'06 03 2021 10:00:57'),(35,29,5,'like',0,0,0,'06 03 2021 10:01:01'),(36,28,5,'like',0,0,1,'06 03 2021 10:01:24'),(37,28,5,'Beautiful image',1,0,1,'06 03 2021 10:01:45'),(38,32,5,'like',0,0,0,'06 03 2021 10:03:42'),(39,26,5,'like',0,0,1,'06 03 2021 10:20:50'),(40,26,5,'Beautiful girl',1,0,1,'06 03 2021 10:21:09'),(41,32,1,'like',0,0,0,'13 03 2021 16:34:54'),(42,27,1,'Hello',1,0,1,'13 03 2021 18:06:40'),(43,20,2,'Anh viết bài chất vậy ...',1,0,1,'13 03 2021 21:20:50'),(44,29,2,'Code dữ vậy em.',1,0,0,'14 03 2021 08:47:39'),(45,27,1,'Em nhớ ai vậy',1,0,1,'14 03 2021 08:56:38'),(46,20,2,'like',0,0,1,'14 03 2021 09:06:53'),(47,34,7,'like',0,0,0,'14 03 2021 17:34:55'),(48,34,1,'like',0,0,1,'14 03 2021 17:35:14'),(49,34,1,'Thơ hay...',1,0,1,'14 03 2021 17:35:24'),(50,34,7,'Ok bạn',1,0,0,'14 03 2021 20:11:09'),(51,29,7,'like',0,0,0,'14 03 2021 20:18:18'),(52,34,2,'like',0,0,1,'14 03 2021 20:24:33'),(53,35,8,'like',0,0,0,'14 03 2021 20:55:42'),(54,34,7,'Thank for you.',1,0,0,'14 03 2021 21:05:20'),(55,36,10,'like',0,0,0,'15 03 2021 08:33:15'),(56,36,1,'like',0,0,1,'15 03 2021 01:57:29'),(57,36,1,'test',1,0,1,'15 03 2021 01:57:39'),(58,28,7,'Test',1,0,1,'15 03 2021 02:02:47'),(59,34,7,'Test\r\n',1,0,0,'15 03 2021 02:03:09'),(60,32,1,'Test ',1,0,0,'17 03 2021 09:45:16');
/*!40000 ALTER TABLE `share_like_comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `ID` int(12) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pass` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mobile` int(10) DEFAULT NULL,
  `gender` int(10) DEFAULT NULL,
  `level` int(2) DEFAULT NULL,
  `created_at` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_update` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `avatar` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `country` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'Võ Đình Nghĩa','4a3396f4fcc5bffd73c6c2276f8b664e','vodinhnghiaskype@gmail.com',365572875,1,0,'01 02 2021 21:28:52','16 03 2021 21:20:44','','Vietnam'),(2,'Võ Thị Tuyết Linh','43fb94da1177864aa7a9fbb7f072b1e9','vothituyetlinh99@gmail.com',372129501,0,0,'04 02 2021 20:42:13','27 02 2021 10:26:05','/images/avatars/15-02-2021-106712292_979102752520719_7452376421506811259_n.jpg','Phu Yen, Viet Nam'),(3,'Admin','b67e6428abfd27b95dad3a8ca26f38a7','admin123@gmail.com',365572875,1,1,'12 02 2021 08:16:31','','','Việt Nam'),(4,'Đình Nghĩa','4a3396f4fcc5bffd73c6c2276f8b664e','vodinhnghia@gmail.com',365572875,1,0,'16 02 2021 10:36:25','15 03 2021 08:24:28','/images/avatars/16-02-2021-15036301_834215213385325_8760571512419874799_n.jpg','Bình Hiệp, Bình Sơn, Quảng Ngãi'),(5,'Nghĩa Bình Hiệp','4a3396f4fcc5bffd73c6c2276f8b664e','dinhnghia@gmail.com',365572875,1,0,'03 03 2021 19:55:44','06 03 2021 10:18:56','/images/avatars/06-03-2021-photocat.jpg','Bình Hiệp, Bình Sơn, Quảng Ngãi'),(7,'Võ Nghĩa ','113de9f99888129b5aa80eee5d61ef22','vodinhnghia85@gmail.com',365572875,1,0,'14 03 2021 16:48:56','14 03 2021 20:23:59','','Vietnam'),(8,'Kiều Phong','4b2e0a423c324fe8fbd9b8040f7a4a59','kieuphong@gmail.com',223456677,1,0,'14 03 2021 20:51:46','14 03 2021 20:54:22','','Bang chủ Cái Ban, truyện Kim Dung'),(10,'Nguyễn Thị A','5066222e2beb300edae00d1ac42bb85e','nguyenthia@gmail.com',387777994,0,0,'15 03 2021 08:29:09','16 03 2021 08:01:35','/images/avatars/16-03-2021-avatar-female.jpg','Quảng Ngãi, Việt Nam');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'blog_nodejs'
--

--
-- Dumping routines for database 'blog_nodejs'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-04-14  1:48:45
