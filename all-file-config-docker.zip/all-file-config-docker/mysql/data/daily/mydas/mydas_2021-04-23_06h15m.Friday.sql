-- MySQL dump 10.13  Distrib 5.7.33, for Linux (x86_64)
--
-- Host: localhost    Database: mydas
-- ------------------------------------------------------
-- Server version	5.7.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `mydas`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `mydas` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `mydas`;

--
-- Table structure for table `agencies`
--

DROP TABLE IF EXISTS `agencies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agencies` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `agent_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agencies`
--

LOCK TABLES `agencies` WRITE;
/*!40000 ALTER TABLE `agencies` DISABLE KEYS */;
/*!40000 ALTER TABLE `agencies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bot_forward_mess`
--

DROP TABLE IF EXISTS `bot_forward_mess`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bot_forward_mess` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_bot` int(11) NOT NULL,
  `from` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `to` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `num_enter` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '1',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `type_forward` tinyint(4) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bot_forward_mess`
--

LOCK TABLES `bot_forward_mess` WRITE;
/*!40000 ALTER TABLE `bot_forward_mess` DISABLE KEYS */;
/*!40000 ALTER TABLE `bot_forward_mess` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bot_send_message`
--

DROP TABLE IF EXISTS `bot_send_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bot_send_message` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_bot` int(11) NOT NULL,
  `user_id_subscribe_bot` int(11) NOT NULL,
  `message` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `set_time` mediumtext COLLATE utf8mb4_unicode_ci,
  `type_send` tinyint(4) NOT NULL DEFAULT '1',
  `inline_keyboard` mediumtext COLLATE utf8mb4_unicode_ci,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `once` datetime DEFAULT NULL,
  `period` int(11) DEFAULT NULL,
  `everyday` time DEFAULT NULL,
  `start` datetime DEFAULT NULL,
  `end` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bot_send_message`
--

LOCK TABLES `bot_send_message` WRITE;
/*!40000 ALTER TABLE `bot_send_message` DISABLE KEYS */;
/*!40000 ALTER TABLE `bot_send_message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bot_set_auto_send_message`
--

DROP TABLE IF EXISTS `bot_set_auto_send_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bot_set_auto_send_message` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_bot` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `message` longtext COLLATE utf8mb4_unicode_ci,
  `count_day` int(11) NOT NULL DEFAULT '1',
  `time` time DEFAULT NULL,
  `attach` mediumtext COLLATE utf8mb4_unicode_ci,
  `sent_day` datetime DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bot_set_auto_send_message`
--

LOCK TABLES `bot_set_auto_send_message` WRITE;
/*!40000 ALTER TABLE `bot_set_auto_send_message` DISABLE KEYS */;
/*!40000 ALTER TABLE `bot_set_auto_send_message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bot_telegram`
--

DROP TABLE IF EXISTS `bot_telegram`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bot_telegram` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `is_bot` tinyint(1) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_bot` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `btn_inline` text COLLATE utf8mb4_unicode_ci,
  `del_msg_inviter` tinyint(4) DEFAULT NULL,
  `del_msg_out` tinyint(4) DEFAULT NULL,
  `dis_notify_msg` tinyint(4) DEFAULT NULL,
  `invite_bot` tinyint(4) DEFAULT NULL,
  `allow_forward` text COLLATE utf8mb4_unicode_ci,
  `limit_mess` text COLLATE utf8mb4_unicode_ci,
  `msg_inviter` text COLLATE utf8mb4_unicode_ci,
  `find_raw` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bot_telegram`
--

LOCK TABLES `bot_telegram` WRITE;
/*!40000 ALTER TABLE `bot_telegram` DISABLE KEYS */;
/*!40000 ALTER TABLE `bot_telegram` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bot_telegram_group`
--

DROP TABLE IF EXISTS `bot_telegram_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bot_telegram_group` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_bot` int(11) NOT NULL,
  `name_bot` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username_bot` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_group` int(11) NOT NULL,
  `name_group` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username_group` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_inviter_id` int(11) NOT NULL,
  `user_inviter_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_kick_id` int(11) DEFAULT NULL,
  `user_kick_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bot_telegram_group`
--

LOCK TABLES `bot_telegram_group` WRITE;
/*!40000 ALTER TABLE `bot_telegram_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `bot_telegram_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bot_telegram_inviter`
--

DROP TABLE IF EXISTS `bot_telegram_inviter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bot_telegram_inviter` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_user_inviter` int(11) NOT NULL,
  `is_bot_inviter` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username_inviter` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_group` int(11) NOT NULL,
  `name_group` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type_group` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` datetime NOT NULL,
  `id_user` int(11) NOT NULL,
  `is_bot_user` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `firstname_user` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username_user` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bot_telegram_inviter`
--

LOCK TABLES `bot_telegram_inviter` WRITE;
/*!40000 ALTER TABLE `bot_telegram_inviter` DISABLE KEYS */;
/*!40000 ALTER TABLE `bot_telegram_inviter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bot_telegram_list_callback`
--

DROP TABLE IF EXISTS `bot_telegram_list_callback`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bot_telegram_list_callback` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_bot` bigint(20) NOT NULL,
  `message` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `notify` tinyint(4) NOT NULL DEFAULT '0',
  `inline_keyboard` mediumtext COLLATE utf8mb4_unicode_ci,
  `user_id` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `type_send` tinyint(4) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bot_telegram_list_callback`
--

LOCK TABLES `bot_telegram_list_callback` WRITE;
/*!40000 ALTER TABLE `bot_telegram_list_callback` DISABLE KEYS */;
/*!40000 ALTER TABLE `bot_telegram_list_callback` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bot_telegram_returned_message`
--

DROP TABLE IF EXISTS `bot_telegram_returned_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bot_telegram_returned_message` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_bot` int(11) NOT NULL,
  `text_setting` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `results_returned` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `message` mediumtext COLLATE utf8mb4_unicode_ci,
  `type_send` tinyint(4) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bot_telegram_returned_message`
--

LOCK TABLES `bot_telegram_returned_message` WRITE;
/*!40000 ALTER TABLE `bot_telegram_returned_message` DISABLE KEYS */;
/*!40000 ALTER TABLE `bot_telegram_returned_message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bot_telegram_subscribe`
--

DROP TABLE IF EXISTS `bot_telegram_subscribe`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bot_telegram_subscribe` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_bot` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `first_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` datetime NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `bot_telegram_subscribe_id_bot_unique` (`id_bot`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bot_telegram_subscribe`
--

LOCK TABLES `bot_telegram_subscribe` WRITE;
/*!40000 ALTER TABLE `bot_telegram_subscribe` DISABLE KEYS */;
/*!40000 ALTER TABLE `bot_telegram_subscribe` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bot_telegram_waiting`
--

DROP TABLE IF EXISTS `bot_telegram_waiting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bot_telegram_waiting` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_bot` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `message` longtext COLLATE utf8mb4_unicode_ci,
  `count_day` int(11) NOT NULL DEFAULT '1',
  `time` time DEFAULT NULL,
  `attach` mediumtext COLLATE utf8mb4_unicode_ci,
  `sent_day` datetime DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bot_telegram_waiting`
--

LOCK TABLES `bot_telegram_waiting` WRITE;
/*!40000 ALTER TABLE `bot_telegram_waiting` DISABLE KEYS */;
/*!40000 ALTER TABLE `bot_telegram_waiting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contacts`
--

DROP TABLE IF EXISTS `contacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contacts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint(4) NOT NULL,
  `is_category` tinyint(4) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contacts`
--

LOCK TABLES `contacts` WRITE;
/*!40000 ALTER TABLE `contacts` DISABLE KEYS */;
/*!40000 ALTER TABLE `contacts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint(3) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `members_contact`
--

DROP TABLE IF EXISTS `members_contact`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `members_contact` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `contact_id` bigint(20) unsigned NOT NULL,
  `first_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone_number` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `extra` text COLLATE utf8mb4_unicode_ci,
  `merge_information` text COLLATE utf8mb4_unicode_ci,
  `merge_ids` text COLLATE utf8mb4_unicode_ci,
  `is_merged` tinyint(4) NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `members_contact`
--

LOCK TABLES `members_contact` WRITE;
/*!40000 ALTER TABLE `members_contact` DISABLE KEYS */;
/*!40000 ALTER TABLE `members_contact` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_resets_table',1),(3,'2019_08_19_000000_create_failed_jobs_table',1),(4,'2016_06_10_230148_create_acl_tables',2),(5,'2020_12_15_072319_create_settings_table',2),(6,'2020_12_18_064024_edit_users_table',3),(7,'2020_12_30_074751_create_agencies_table',3),(8,'2021_02_04_142104_create_contacts_table',4),(9,'2021_02_22_091435_create_related_contacts_table',4),(10,'2021_02_22_092201_create_members_contact_table',4),(11,'2021_01_06_080133_create_bot_telegram_subscribe_table',5),(12,'2021_01_06_083017_create_bot_telegram_table',5),(13,'2021_01_12_035708_create_bot_telegram_returned_message_table',5),(14,'2021_01_13_072708_create_bot_telegram_list_callback_table',5),(15,'2021_01_14_031703_create_bot_send_message_table',5),(16,'2021_01_22_144849_create_bot_set_auto_send_message_table',5),(17,'2021_01_27_092821_create_bot_forward_mess_table',5),(18,'2021_02_01_090255_create_bot_telegram_group_table',5),(19,'2021_02_02_145449_create_bot_telegram_waiting_table',5),(20,'2021_02_03_110915_create_bot_telegram_inviter_table',5),(21,'2021_03_10_103613_create_zalo_accounts_table',6),(22,'2021_03_10_104605_create_zalo_friends_table',6),(23,'2021_03_10_104825_create_zalo_groups_table',6),(24,'2021_03_10_105328_create_zalo_group_members_table',6),(25,'2020_12_24_025319_create_telegram_accounts_table',7),(26,'2020_12_26_163347_create_telegram_friends_table',7),(27,'2020_12_28_062602_create_telegram_groups_table',7),(28,'2020_12_28_102617_create_telegram_group_invitations_table',7),(29,'2020_12_28_102618_create_telegram_group_invitation_details_table',7),(30,'2020_12_29_034258_create_telegram_group_invitation_account_table',7),(31,'2020_12_29_034432_create_telegram_group_invitation_group_table',7),(32,'2020_12_30_043641_create_telegram_group_members',7),(33,'2021_01_06_071118_create_telegram_messages_table',7),(34,'2021_01_06_143207_create_telegram_message_account_table',7),(35,'2021_01_08_111312_create_telegram_message_details_table',7),(36,'2021_01_08_111401_create_telegram_message_process_table',7),(37,'2021_01_15_112448_create_jobs_table',7),(38,'2021_01_20_110228_create_telegram_group_invitation_process_table',7);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `places`
--

DROP TABLE IF EXISTS `places`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `places` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `visited` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `places`
--

LOCK TABLES `places` WRITE;
/*!40000 ALTER TABLE `places` DISABLE KEYS */;
INSERT INTO `places` VALUES (12,'Berlin',0),(13,'Budapest',0),(14,'Cincinnati',1),(15,'Denver',0),(16,'Helsinki',0),(17,'Lisbon',0),(18,'Moscow',1),(19,'Nairobi',0),(20,'Oslo',1),(21,'Rio',0),(22,'Tokyo',0);
/*!40000 ALTER TABLE `places` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `related_contacts`
--

DROP TABLE IF EXISTS `related_contacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `related_contacts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `child_id` bigint(20) unsigned NOT NULL,
  `parent_id` bigint(20) unsigned NOT NULL,
  `status` tinyint(4) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `related_contacts`
--

LOCK TABLES `related_contacts` WRITE;
/*!40000 ALTER TABLE `related_contacts` DISABLE KEYS */;
/*!40000 ALTER TABLE `related_contacts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `settings_key_unique` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES (1,'activated_plugins','[\"auth\",\"super-contact\",\"bot-telegram\",\"dev-tool\",\"error-handler\",\"schedule\",\"zalo\",\"telegram\"]',NULL,NULL);
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `telegram_accounts`
--

DROP TABLE IF EXISTS `telegram_accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `telegram_accounts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `account_id` int(11) DEFAULT NULL,
  `api_id` int(10) unsigned DEFAULT NULL,
  `api_hash` mediumtext COLLATE utf8mb4_unicode_ci,
  `phone_code_hash` mediumtext COLLATE utf8mb4_unicode_ci,
  `access_hash` mediumtext COLLATE utf8mb4_unicode_ci,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `username` mediumtext COLLATE utf8mb4_unicode_ci,
  `first_name` mediumtext COLLATE utf8mb4_unicode_ci,
  `last_name` mediumtext COLLATE utf8mb4_unicode_ci,
  `status` tinyint(4) NOT NULL DEFAULT '2',
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `find_raw` mediumtext COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `telegram_accounts_user_id_foreign` (`user_id`),
  CONSTRAINT `telegram_accounts_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `telegram_accounts`
--

LOCK TABLES `telegram_accounts` WRITE;
/*!40000 ALTER TABLE `telegram_accounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `telegram_accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `telegram_friends`
--

DROP TABLE IF EXISTS `telegram_friends`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `telegram_friends` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `tlg_account_id` bigint(20) unsigned NOT NULL,
  `account_id` int(11) DEFAULT NULL,
  `first_name` mediumtext COLLATE utf8mb4_unicode_ci,
  `last_name` mediumtext COLLATE utf8mb4_unicode_ci,
  `username` mediumtext COLLATE utf8mb4_unicode_ci,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `access_hash` mediumtext COLLATE utf8mb4_unicode_ci,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `find_raw` mediumtext COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `telegram_friends_user_id_foreign` (`user_id`),
  KEY `telegram_friends_tlg_account_id_foreign` (`tlg_account_id`),
  CONSTRAINT `telegram_friends_tlg_account_id_foreign` FOREIGN KEY (`tlg_account_id`) REFERENCES `telegram_accounts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `telegram_friends_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `telegram_friends`
--

LOCK TABLES `telegram_friends` WRITE;
/*!40000 ALTER TABLE `telegram_friends` DISABLE KEYS */;
/*!40000 ALTER TABLE `telegram_friends` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `telegram_g_invitation_account`
--

DROP TABLE IF EXISTS `telegram_g_invitation_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `telegram_g_invitation_account` (
  `tlg_g_invitation_id` bigint(20) unsigned NOT NULL,
  `tlg_account_id` bigint(20) unsigned NOT NULL,
  KEY `telegram_g_invitation_account_tlg_g_invitation_id_foreign` (`tlg_g_invitation_id`),
  KEY `telegram_g_invitation_account_tlg_account_id_foreign` (`tlg_account_id`),
  CONSTRAINT `telegram_g_invitation_account_tlg_account_id_foreign` FOREIGN KEY (`tlg_account_id`) REFERENCES `telegram_accounts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `telegram_g_invitation_account_tlg_g_invitation_id_foreign` FOREIGN KEY (`tlg_g_invitation_id`) REFERENCES `telegram_g_invitations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `telegram_g_invitation_account`
--

LOCK TABLES `telegram_g_invitation_account` WRITE;
/*!40000 ALTER TABLE `telegram_g_invitation_account` DISABLE KEYS */;
/*!40000 ALTER TABLE `telegram_g_invitation_account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `telegram_g_invitation_details`
--

DROP TABLE IF EXISTS `telegram_g_invitation_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `telegram_g_invitation_details` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `invited_id` bigint(20) unsigned NOT NULL,
  `tlg_g_invitation_id` bigint(20) unsigned NOT NULL,
  `tlg_group_id` bigint(20) unsigned DEFAULT NULL,
  `tlg_account_id` bigint(20) unsigned NOT NULL,
  `tlg_id` int(11) DEFAULT NULL,
  `first_name` mediumtext COLLATE utf8mb4_unicode_ci,
  `last_name` mediumtext COLLATE utf8mb4_unicode_ci,
  `username` mediumtext COLLATE utf8mb4_unicode_ci,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` tinyint(4) DEFAULT NULL,
  `find_raw` mediumtext COLLATE utf8mb4_unicode_ci,
  `status` tinyint(4) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `telegram_g_invitation_details_tlg_g_invitation_id_foreign` (`tlg_g_invitation_id`),
  KEY `telegram_g_invitation_details_tlg_group_id_foreign` (`tlg_group_id`),
  KEY `telegram_g_invitation_details_tlg_account_id_foreign` (`tlg_account_id`),
  CONSTRAINT `telegram_g_invitation_details_tlg_account_id_foreign` FOREIGN KEY (`tlg_account_id`) REFERENCES `telegram_accounts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `telegram_g_invitation_details_tlg_g_invitation_id_foreign` FOREIGN KEY (`tlg_g_invitation_id`) REFERENCES `telegram_g_invitations` (`id`) ON DELETE CASCADE,
  CONSTRAINT `telegram_g_invitation_details_tlg_group_id_foreign` FOREIGN KEY (`tlg_group_id`) REFERENCES `telegram_groups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `telegram_g_invitation_details`
--

LOCK TABLES `telegram_g_invitation_details` WRITE;
/*!40000 ALTER TABLE `telegram_g_invitation_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `telegram_g_invitation_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `telegram_g_invitation_group`
--

DROP TABLE IF EXISTS `telegram_g_invitation_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `telegram_g_invitation_group` (
  `tlg_g_invitation_id` bigint(20) unsigned NOT NULL,
  `tlg_group_id` bigint(20) unsigned NOT NULL,
  KEY `telegram_g_invitation_group_tlg_g_invitation_id_foreign` (`tlg_g_invitation_id`),
  KEY `telegram_g_invitation_group_tlg_group_id_foreign` (`tlg_group_id`),
  CONSTRAINT `telegram_g_invitation_group_tlg_g_invitation_id_foreign` FOREIGN KEY (`tlg_g_invitation_id`) REFERENCES `telegram_g_invitations` (`id`) ON DELETE CASCADE,
  CONSTRAINT `telegram_g_invitation_group_tlg_group_id_foreign` FOREIGN KEY (`tlg_group_id`) REFERENCES `telegram_groups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `telegram_g_invitation_group`
--

LOCK TABLES `telegram_g_invitation_group` WRITE;
/*!40000 ALTER TABLE `telegram_g_invitation_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `telegram_g_invitation_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `telegram_g_invitation_process`
--

DROP TABLE IF EXISTS `telegram_g_invitation_process`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `telegram_g_invitation_process` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tlg_g_invitation_detail_id` bigint(20) unsigned NOT NULL,
  `tlg_group_id` bigint(20) unsigned NOT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `status_code` int(11) DEFAULT NULL,
  `status_mess` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `telegram_g_invitation_process_tlg_g_invitation_detail_id_foreign` (`tlg_g_invitation_detail_id`),
  KEY `telegram_g_invitation_process_tlg_group_id_foreign` (`tlg_group_id`),
  CONSTRAINT `telegram_g_invitation_process_tlg_g_invitation_detail_id_foreign` FOREIGN KEY (`tlg_g_invitation_detail_id`) REFERENCES `telegram_g_invitation_details` (`id`) ON DELETE CASCADE,
  CONSTRAINT `telegram_g_invitation_process_tlg_group_id_foreign` FOREIGN KEY (`tlg_group_id`) REFERENCES `telegram_groups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `telegram_g_invitation_process`
--

LOCK TABLES `telegram_g_invitation_process` WRITE;
/*!40000 ALTER TABLE `telegram_g_invitation_process` DISABLE KEYS */;
/*!40000 ALTER TABLE `telegram_g_invitation_process` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `telegram_g_invitations`
--

DROP TABLE IF EXISTS `telegram_g_invitations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `telegram_g_invitations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `tlg_account_id_get_user` bigint(20) unsigned DEFAULT NULL,
  `type` tinyint(4) DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '2',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `telegram_g_invitations_user_id_foreign` (`user_id`),
  KEY `telegram_g_invitations_tlg_account_id_get_user_foreign` (`tlg_account_id_get_user`),
  CONSTRAINT `telegram_g_invitations_tlg_account_id_get_user_foreign` FOREIGN KEY (`tlg_account_id_get_user`) REFERENCES `telegram_accounts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `telegram_g_invitations_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `telegram_g_invitations`
--

LOCK TABLES `telegram_g_invitations` WRITE;
/*!40000 ALTER TABLE `telegram_g_invitations` DISABLE KEYS */;
/*!40000 ALTER TABLE `telegram_g_invitations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `telegram_group_members`
--

DROP TABLE IF EXISTS `telegram_group_members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `telegram_group_members` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `chat_id` int(11) DEFAULT NULL,
  `account_id` int(11) DEFAULT NULL,
  `first_name` mediumtext COLLATE utf8mb4_unicode_ci,
  `last_name` mediumtext COLLATE utf8mb4_unicode_ci,
  `username` mediumtext COLLATE utf8mb4_unicode_ci,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `access_hash` mediumtext COLLATE utf8mb4_unicode_ci,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `find_raw` mediumtext COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `telegram_group_members_user_id_foreign` (`user_id`),
  CONSTRAINT `telegram_group_members_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `telegram_group_members`
--

LOCK TABLES `telegram_group_members` WRITE;
/*!40000 ALTER TABLE `telegram_group_members` DISABLE KEYS */;
/*!40000 ALTER TABLE `telegram_group_members` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `telegram_groups`
--

DROP TABLE IF EXISTS `telegram_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `telegram_groups` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `tlg_account_id` bigint(20) unsigned NOT NULL,
  `chat_id` int(11) DEFAULT NULL,
  `access_hash` mediumtext COLLATE utf8mb4_unicode_ci,
  `username` mediumtext COLLATE utf8mb4_unicode_ci,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `find_raw` mediumtext COLLATE utf8mb4_unicode_ci,
  `participants_count` int(10) unsigned NOT NULL DEFAULT '0',
  `date` bigint(20) unsigned NOT NULL,
  `last_update` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `telegram_groups_user_id_foreign` (`user_id`),
  KEY `telegram_groups_tlg_account_id_foreign` (`tlg_account_id`),
  CONSTRAINT `telegram_groups_tlg_account_id_foreign` FOREIGN KEY (`tlg_account_id`) REFERENCES `telegram_accounts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `telegram_groups_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `telegram_groups`
--

LOCK TABLES `telegram_groups` WRITE;
/*!40000 ALTER TABLE `telegram_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `telegram_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `telegram_message_account`
--

DROP TABLE IF EXISTS `telegram_message_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `telegram_message_account` (
  `tlg_message_id` bigint(20) unsigned NOT NULL,
  `tlg_account_id` bigint(20) unsigned NOT NULL,
  KEY `telegram_message_account_tlg_message_id_foreign` (`tlg_message_id`),
  KEY `telegram_message_account_tlg_account_id_foreign` (`tlg_account_id`),
  CONSTRAINT `telegram_message_account_tlg_account_id_foreign` FOREIGN KEY (`tlg_account_id`) REFERENCES `telegram_accounts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `telegram_message_account_tlg_message_id_foreign` FOREIGN KEY (`tlg_message_id`) REFERENCES `telegram_messages` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `telegram_message_account`
--

LOCK TABLES `telegram_message_account` WRITE;
/*!40000 ALTER TABLE `telegram_message_account` DISABLE KEYS */;
/*!40000 ALTER TABLE `telegram_message_account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `telegram_message_details`
--

DROP TABLE IF EXISTS `telegram_message_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `telegram_message_details` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `tlg_account_id` bigint(20) unsigned NOT NULL,
  `tlg_message_id` bigint(20) unsigned NOT NULL,
  `contact_id` bigint(20) unsigned NOT NULL,
  `receiver_id` bigint(20) unsigned NOT NULL,
  `object_type` tinyint(4) DEFAULT NULL,
  `tlg_id` int(11) DEFAULT NULL,
  `first_name` mediumtext COLLATE utf8mb4_unicode_ci,
  `last_name` mediumtext COLLATE utf8mb4_unicode_ci,
  `username` mediumtext COLLATE utf8mb4_unicode_ci,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` mediumtext COLLATE utf8mb4_unicode_ci,
  `type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `find_raw` mediumtext COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `telegram_message_details_user_id_foreign` (`user_id`),
  KEY `telegram_message_details_tlg_account_id_foreign` (`tlg_account_id`),
  KEY `telegram_message_details_tlg_message_id_foreign` (`tlg_message_id`),
  KEY `telegram_message_details_contact_id_foreign` (`contact_id`),
  CONSTRAINT `telegram_message_details_contact_id_foreign` FOREIGN KEY (`contact_id`) REFERENCES `contacts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `telegram_message_details_tlg_account_id_foreign` FOREIGN KEY (`tlg_account_id`) REFERENCES `telegram_accounts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `telegram_message_details_tlg_message_id_foreign` FOREIGN KEY (`tlg_message_id`) REFERENCES `telegram_messages` (`id`) ON DELETE CASCADE,
  CONSTRAINT `telegram_message_details_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `telegram_message_details`
--

LOCK TABLES `telegram_message_details` WRITE;
/*!40000 ALTER TABLE `telegram_message_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `telegram_message_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `telegram_message_process`
--

DROP TABLE IF EXISTS `telegram_message_process`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `telegram_message_process` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tlg_message_detail_id` bigint(20) unsigned NOT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `status_code` int(11) DEFAULT NULL,
  `status_mess` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `telegram_message_process_tlg_message_detail_id_foreign` (`tlg_message_detail_id`),
  CONSTRAINT `telegram_message_process_tlg_message_detail_id_foreign` FOREIGN KEY (`tlg_message_detail_id`) REFERENCES `telegram_message_details` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `telegram_message_process`
--

LOCK TABLES `telegram_message_process` WRITE;
/*!40000 ALTER TABLE `telegram_message_process` DISABLE KEYS */;
/*!40000 ALTER TABLE `telegram_message_process` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `telegram_messages`
--

DROP TABLE IF EXISTS `telegram_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `telegram_messages` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `tlg_account_id_get_user` bigint(20) unsigned DEFAULT NULL,
  `action` tinyint(4) DEFAULT NULL,
  `type` tinyint(4) DEFAULT NULL,
  `object_type` tinyint(4) DEFAULT NULL,
  `sending_time` datetime DEFAULT NULL,
  `number_hours` int(11) DEFAULT NULL,
  `sending_hour` time DEFAULT NULL,
  `sending_date_start` date DEFAULT NULL,
  `sending_date_end` date DEFAULT NULL,
  `message` mediumtext COLLATE utf8mb4_unicode_ci,
  `status` tinyint(4) NOT NULL DEFAULT '2',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `telegram_messages_user_id_foreign` (`user_id`),
  KEY `telegram_messages_tlg_account_id_get_user_foreign` (`tlg_account_id_get_user`),
  CONSTRAINT `telegram_messages_tlg_account_id_get_user_foreign` FOREIGN KEY (`tlg_account_id_get_user`) REFERENCES `telegram_accounts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `telegram_messages_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `telegram_messages`
--

LOCK TABLES `telegram_messages` WRITE;
/*!40000 ALTER TABLE `telegram_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `telegram_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `fullname` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gender` tinyint(4) NOT NULL DEFAULT '1',
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `affilate` tinyint(4) NOT NULL DEFAULT '0',
  `user_code` bigint(20) DEFAULT NULL,
  `fcode` int(11) DEFAULT NULL,
  `token_aff_sys` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `level` int(11) NOT NULL DEFAULT '1',
  `logo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_login` datetime NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `zalo_accounts`
--

DROP TABLE IF EXISTS `zalo_accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `zalo_accounts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `account_id` mediumtext COLLATE utf8mb4_unicode_ci,
  `data_cookie` longtext COLLATE utf8mb4_unicode_ci,
  `data_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `display_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `zalo_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `avatar` mediumtext COLLATE utf8mb4_unicode_ci,
  `cover` mediumtext COLLATE utf8mb4_unicode_ci,
  `sdob` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gender` tinyint(4) DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `find_raw` mediumtext COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `zalo_accounts_user_id_foreign` (`user_id`),
  CONSTRAINT `zalo_accounts_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `zalo_accounts`
--

LOCK TABLES `zalo_accounts` WRITE;
/*!40000 ALTER TABLE `zalo_accounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `zalo_accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `zalo_friends`
--

DROP TABLE IF EXISTS `zalo_friends`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `zalo_friends` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `zl_account_id` bigint(20) unsigned DEFAULT NULL,
  `account_id` mediumtext COLLATE utf8mb4_unicode_ci,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `display_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `zalo_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `avatar` mediumtext COLLATE utf8mb4_unicode_ci,
  `cover` mediumtext COLLATE utf8mb4_unicode_ci,
  `sdob` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gender` tinyint(4) DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '2',
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `find_raw` mediumtext COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `zalo_friends_zl_account_id_foreign` (`zl_account_id`),
  KEY `zalo_friends_user_id_foreign` (`user_id`),
  CONSTRAINT `zalo_friends_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `zalo_friends_zl_account_id_foreign` FOREIGN KEY (`zl_account_id`) REFERENCES `zalo_accounts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `zalo_friends`
--

LOCK TABLES `zalo_friends` WRITE;
/*!40000 ALTER TABLE `zalo_friends` DISABLE KEYS */;
/*!40000 ALTER TABLE `zalo_friends` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `zalo_group_members`
--

DROP TABLE IF EXISTS `zalo_group_members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `zalo_group_members` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `zl_group_id` bigint(20) unsigned DEFAULT NULL,
  `account_id` mediumtext COLLATE utf8mb4_unicode_ci,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `display_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `zalo_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `avatar` mediumtext COLLATE utf8mb4_unicode_ci,
  `cover` mediumtext COLLATE utf8mb4_unicode_ci,
  `sdob` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gender` tinyint(4) DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '2',
  `find_raw` mediumtext COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `zalo_group_members_zl_group_id_foreign` (`zl_group_id`),
  CONSTRAINT `zalo_group_members_zl_group_id_foreign` FOREIGN KEY (`zl_group_id`) REFERENCES `zalo_groups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `zalo_group_members`
--

LOCK TABLES `zalo_group_members` WRITE;
/*!40000 ALTER TABLE `zalo_group_members` DISABLE KEYS */;
/*!40000 ALTER TABLE `zalo_group_members` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `zalo_groups`
--

DROP TABLE IF EXISTS `zalo_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `zalo_groups` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `zl_account_id` bigint(20) unsigned DEFAULT NULL,
  `group_id` mediumtext COLLATE utf8mb4_unicode_ci,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `avatar` mediumtext COLLATE utf8mb4_unicode_ci,
  `creator_id` int(11) DEFAULT NULL,
  `created_time` int(11) DEFAULT NULL,
  `total_member` int(11) DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '2',
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `find_raw` mediumtext COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `zalo_groups_zl_account_id_foreign` (`zl_account_id`),
  KEY `zalo_groups_user_id_foreign` (`user_id`),
  CONSTRAINT `zalo_groups_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `zalo_groups_zl_account_id_foreign` FOREIGN KEY (`zl_account_id`) REFERENCES `zalo_accounts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `zalo_groups`
--

LOCK TABLES `zalo_groups` WRITE;
/*!40000 ALTER TABLE `zalo_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `zalo_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'mydas'
--

--
-- Dumping routines for database 'mydas'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-04-23  6:15:03
